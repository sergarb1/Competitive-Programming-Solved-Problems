#!/bin/bash

./Main.py < a_example.in  > a_example.out
./Main.py < b_should_be_easy.in  > b_should_be_easy.out 
./Main.py < c_no_hurry.in  > c_no_hurry.out 
./Main.py < d_metropolis.in  > d_metropolis.out 
./Main.py < e_high_bonus.in  > e_high_bonus.out 

